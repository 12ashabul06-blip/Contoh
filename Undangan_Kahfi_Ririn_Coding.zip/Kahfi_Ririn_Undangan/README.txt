UNDANGAN DIGITAL KAHFI & RIRIN

FILE:
- index.html: isi dan susunan halaman
- style.css: warna, tipografi, layout dan animasi
- script.js: nama tamu, countdown, navigasi, ucapan
- assets/: aset dari file referensi MHT (hanya referensi; tidak dipakai otomatis agar foto pasangan demo tidak tampil di undangan Anda)

CARA PAKAI:
1. Ekstrak ZIP.
2. Buka index.html untuk melihat website. Internet diperlukan untuk font Google.
3. Untuk nama tamu personal, buka: index.html?to=Nama%20Tamu
4. Tanggal akad: 25 November 2026 pukul 10.00 WITA. Resepsi: 26 November 2026 pukul 13.00–17.00 WITA.
5. Lokasi, rekening BCA/DANA, alamat kirim hadiah, foto pasangan, dan kisah pribadi belum diisi karena datanya belum tersedia/terkonfirmasi. Ganti placeholder di index.html dan style.css.
6. Ucapan di versi ini hanya tersimpan sementara di browser pengunjung; perlu backend/database agar terkumpul online.
7. Untuk memasang musik, letakkan file legal milik Anda di assets/music.mp3 lalu buka script.js dan aktifkan baris music.src.

CATATAN DESAIN:
Struktur halaman mempertahankan alur referensi: sampul dan tombol buka, salam, profil pasangan, countdown, acara, kisah, galeri, hadiah, ucapan, penutup, serta navigasi bawah. Tema diganti ke abu-abu, navy, dan gold. Foto asli pasangan belum tersedia sehingga area foto dibuat placeholder agar tidak menampilkan pasangan dari template demo.
